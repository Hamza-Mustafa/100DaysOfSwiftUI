//
//  ViewController.swift
//  ImperativeStates
//
//  Created by Hamza Mustafa on 05/10/2021.
//

import UIKit

class ViewController: UITableViewController {
    
    var textLabel : UILabel?
    
    lazy var textField:UITextField! = { [unowned self] in
        let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.placeholder = "Enter Your Name :"
        textField.addTarget(self, action: #selector(whenTextFieldDidChange), for: .editingChanged)
        return textField
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "TextFieldCell")
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "LabelCell")
    }
    
    @objc func whenTextFieldDidChange(_ textField: UITextField) {
        guard let newText = textField.text else {
            return
        }
        textLabel?.text = "Your text is \(newText)"
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell
        if indexPath.row == 0 {
            cell = tableView.dequeueReusableCell(withIdentifier: "TextFieldCell", for: indexPath)
            cell.contentView.addSubview(textField)
            setConstraint(in: cell)
        }else{
            cell = tableView.dequeueReusableCell(withIdentifier: "LabelCell", for: indexPath)
            textLabel = cell.textLabel
            textLabel?.text = "Your name is \("")"
        }
        return cell
    }
    
    private func setConstraint(in cell: UITableViewCell) {
        textField.leadingAnchor.constraint(equalTo: cell.leadingAnchor, constant: 15).isActive = true
        textField.trailingAnchor.constraint(equalTo: cell.trailingAnchor, constant: -15).isActive = true
        textField.topAnchor.constraint(equalTo: cell.topAnchor).isActive = true
        textField.bottomAnchor.constraint(equalTo: cell.bottomAnchor).isActive = true
    }
}
