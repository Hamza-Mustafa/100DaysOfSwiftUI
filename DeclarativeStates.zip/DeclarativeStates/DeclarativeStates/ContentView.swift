//
//  ContentView.swift
//  DeclarativeStates
//
//  Created by Hamza Mustafa on 05/10/2021.
//

import SwiftUI

struct ContentView: View {
    
    @State private var name = ""
    
    var body: some View {
        Form{
            TextField("Enter Your Name:", text: $name)
            Text("Your Name is \(name)")
        }
    }
}

// This Code is responsible for generating preview only
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
